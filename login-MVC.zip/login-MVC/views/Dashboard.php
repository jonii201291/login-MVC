<?php
// views/login.php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
       // habría que comprobar que hay token de sesion
?>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
        <link rel="stylesheet" type="text/css" href="estilo.css" title="style" media="screen">

</head>

<body>
    <h2>Bienvenido al Dashboard, <?php echo $_SESSION['idusuario'] ?></h2>
    <p>Has iniciado sesión correctamente</p>
    <a href="index.php?route=login">Cerrar sesión (Volver al login)</a>
</body>

</html>