<?php
// views/login.php

if (isset($_SESSION['usuario_logueado'])) {  // si el usuario estuviera ya logeado, lo derivamos al inicio interno
    header("Location: index.php?action=dashboard");   // nosotros haremos comprobación de token
    exit();
}
    

?>
<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <style>
        body{
            background: linear-gradient(to bottom, black, #00FFFF);
            min-height: 100vh;
            margin: 0;        
            display: flex;
            justify-content: center;
            align-items: center;

            font-family: Arial, sans-serif;
            color: #fff;
        }

        form {
            background-color: rgba(0, 0, 0, 0.3);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.5);
            width: 300px;
        }

        #loginForm input{
            padding: 12px 15px;   
            font-size: 16px;      
            border-radius: 10px;  
            border: 1px solid #ccc;
            margin-bottom: 15px;    
            width: 100%;           
            box-sizing: border-box; 
            transition: border 0.3s;
        }

        
        #loginForm input[type="text"]:focus,
        #loginForm input[type="password"]:focus {
            border: 1px solid #007BFF;
            outline: none;         
        }

        #loginForm button{
            display: block;        
            margin: 20px auto;     
            padding: 12px 30px;    
            font-size: 16px;
            font-family: 'Segoe UI', Tahoma, sans-serif;           
            font-weight: 600;
            border-radius: 25px;   
            border: none;
            cursor: pointer;

            background: linear-gradient(135deg, black, #00CFFF);
            color: white;

            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        #loginForm button:hover{
            transform: scale(1.05);
            box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.25);
        }

        #loginForm button:active{
            transform: scale(0.98);
        }

        #loginForm fieldset{
            border: none;
            text-align: center;
        }

        #errores {
            width: 100%;
            min-height: 20px;
            margin-bottom: 15px;
            text-align: center;
        }

        .error{
            color: red;
            width: 100%;
            text-align: center;
        }

        .errorSQL{
            color: red;
            font-size: 25px;
            position: fixed;
            height: 100%;
            text-align: center;
        }
    </style>
</head>

<body>
    <!-- aquí podríamos hacer un include de una cabecera común, si la hubiera, que incluyera incluso todas las etiquetas HTML anteriores -->

   
    <script>
        function validarFormulario(event) {
            event.preventDefault(); // Evita enviar si hay errores

            const idusuario = document.getElementById('idusuario').value.trim();
            const password = document.getElementById('password').value;

            let errores = [];

            // Validación idusuario: alfanumérico 3-20 caracteres
            const idusuarioRegex = /^[a-zA-Z0-9]{3,20}$/;
            if (!idusuarioRegex.test(idusuario)) {
                errores.push("El idusuario debe tener entre 3 y 20 caracteres alfanuméricos.");
            }

            // Validación password: al menos 9 caracteres, mayúscula, minúscula, número y símbolo
            const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{9,}$/;
            if (!passwordRegex.test(password)) {
                errores.push("La contraseña debe tener al menos 9 caracteres, incluyendo mayúsculas, minúsculas, números y símbolos.");
            }

            // Mostrar errores
            const errorDiv = document.getElementById('errores');
            errorDiv.innerHTML = '';
            if (errores.length > 0) {
                errores.forEach(err => {
                    const p = document.createElement('p');
                    p.style.color = 'red';
                    p.textContent = err;
                    errorDiv.appendChild(p);
                });
                return false; // No enviar formulario
            } else {
                document.getElementById('loginForm').submit();
            }
        }
    </script>
 
    <form id="loginForm" action="index.php?action=authenticate" method="POST" onsubmit="validarFormulario(event)">
        <?php
        if (isset($_GET['error'])) {
            echo '<p class="error">' . $_GET['error'] . "</p>";       
            unset($_GET['error']);
        }
        ?>    
        <div id="errores"></div>
        <fieldset>INICIO DE SESIÓN</fieldset>
        <input type="text" id="idusuario" name="idusuario" placeholder="Identificador Usuario" required><br><br>
        <input type="password" id="password" name="password" placeholder="Contraseña" required><br><br>
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <button type="submit" name="login">Ingresar</button>
    </form>
    
    <!-- aquí podríamos hacer un include de un pie común, si lo hubiera, que incluyera incluso todas las etiquetas HTML posteriores -->
    
</body>

</html>