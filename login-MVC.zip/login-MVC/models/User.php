<?php
require_once __DIR__ . '/../config/Database.php';

class Usuario
{
    private $PDO;
    private $tabla_nombre = "usuarios1";                 // Tu tabla de usuarios

    public function __construct()
    {
        $database = new Database();                    // aquí se invoca al constructor Database, que crea la conexión
        $this->PDO = $database->getConnection();       // y se almacena en el objeto usuario, cuando se invoca su constructor
    }

    public function registrar($usuario, $password)
    {
    // Genera un hash seguro de la contraseña
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $query = "INSERT INTO " . $this->tabla_nombre . " (usuario, password) VALUES (?, ?)";
    $stmt = $this->PDO->prepare($query);
    return $stmt->execute([$usuario, $hash]);
}

    // Método para verificar usuario y contraseña
    public function login($idusuario, $password)
    {
        $query = "SELECT * FROM " . $this->tabla_nombre . " WHERE usuario = ? LIMIT 0,1";
        $stmt = $this->PDO->prepare($query);
        $stmt->execute([$idusuario]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verifica la contraseña usando password_verify
        if ($user && password_verify($password, $user['password'])) {
        return $user;
    }

        return false;
    }

}