<?php
require_once __DIR__ . '/session.php';
require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/controllers/AuthController.php';

                // el modelo de usuarios son cargados al empezar
												// ambos son declaraciones de clases -> orientación a objetos pura
// Iniciar sesión

$controller = new AuthController();  // se crea una instancia de controlador de usuario (que incluye conexión, tabla, y operatoria con usuarios)

// Regeneración periódica del ID de sesión
$regenerate_interval = 1200; // 20 minutos
if (!isset($_SESSION['last_regeneration'])) {
    $_SESSION['last_regeneration'] = time();
}
if (time() - $_SESSION['last_regeneration'] >= $regenerate_interval) {
    session_regenerate_id(true);
    $_SESSION['last_regeneration'] = time();
}

// Generación de CSRF token si no existe
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(64));
}
																							 // Simple enrutamiento basado en la URL. Se concentra aquí todo el redireccionamiento
if (!isset($_REQUEST['action'])) {             // la primera vez, entramos para hacer login y no hay en la URL action definida
    $controller->login();
} else {
    switch ($_REQUEST['action']) {             // más adelante, podemos venir desde el interior con una action particular en la url
        case 'login':
            $controller->login();              // si la action fuera login
            break;
        case 'authenticate':
            $controller->authenticate();      // si hay que autenticar
            break;
        case 'dashboard':
            $controller->dashboard();         // si vamos a la página interna de inicio de la aplicación
            break;
        case 'logout':
            $controller->logout();            // si cerramos la sesión
            break;
        default:
            $controller->login();
            break;
    }
}