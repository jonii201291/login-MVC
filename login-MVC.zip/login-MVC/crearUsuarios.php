<?php
require_once __DIR__ . '/models/User.php';

$usuarioModel = new Usuario();

$usuario = 'jgamber119';
$password = 'Abc0123456789.';

if ($usuarioModel->registrar($usuario, $password)) {
    echo "Usuario creado correctamente.";
} else {
    echo "Error al crear el usuario.";
}
