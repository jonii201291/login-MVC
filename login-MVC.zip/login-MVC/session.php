<?php
// session.php

if (session_status() == PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 3600,
        'path' => '/',
        'domain' => '', 
        'secure' => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
    session_start();

    // Regeneración periódica del ID de sesión
    $regenerate_interval = 1200; // 20 minutos
    if (!isset($_SESSION['last_regeneration'])) {
        $_SESSION['last_regeneration'] = time();
    }
    if (time() - $_SESSION['last_regeneration'] >= $regenerate_interval) {
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    }

    // CSRF token
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(64));
    }
}
