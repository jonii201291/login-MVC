<?php
require_once __DIR__ . '/../models/User.php';

class AuthController                                   // la clase AuthController contiene un objeto usuario (el que autentica)
{
    private $userModel;

    public function __construct()                     // aquí lo crea
    {
        $this->userModel = new Usuario();
    }

    public function login()                           // aquí ejecuta el login (en realidad, la vista login)
    {
        // Carga la vista del formulario de login
        include 'views/login.php';
    }

    public function authenticate()                    // aquí confronta con la base de datos
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
                die("Solicitud no válida. Token CSRF no coincide.");
            }
            $username = $_POST['idusuario'];
            $password = $_POST['password'];
            $errors = [];

             if (!preg_match('/^[a-zA-Z0-9]{3,20}$/', $username)) {
            $_GET['error'] = "Idusuario inválido.";
            include __DIR__ . '/../views/login.php';
            return;
            }
            if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{9,}$/', $password)) {
                $_GET['error'] = "Contraseña inválida.";
                include __DIR__ . '/../views/login.php';
                return;
            }

            // Si hay errores, se pone login con mensaje
            if (!empty($errors)) {
                $_GET['error'] = implode(" ", $errors);
                include __DIR__ . '/../views/login.php';
                return;
            }

            if ($this->userModel->login($username, $password)) {
                // Autenticación exitosa, iniciar sesión y redirigir al enrutador para que éste envíe al dashboard-inicio
                $_SESSION['idusuario'] = $username;
                header('Location: index.php?action=dashboard');
                exit();
            } else {
                // Autenticación fallida, recargar login con error que mostraría mensaje
                $_GET['error'] = "Usuario o contraseña incorrectos.";
                include __DIR__ . '/../views/login.php';
            }
        }
    }

    public function dashboard()
    {
        // Verificar si el usuario ha iniciado sesión
        if (!isset($_SESSION['idusuario'])) {
            header('Location: index.php?action=login');
            exit();
        }
        // Carga la vista del dashboard (página de bienvenida)
        include __DIR__ . '/../views/dashboard.php';
    }

    public function logout()
    {
        $_SESSION = [];

        // Eliminar cookie de sesión
        if (isset($_COOKIE[session_name()])) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', 1, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }

        // Destruir sesión
        session_destroy();

        header('Location: index.php?action=login');
        exit();
    }
}